This directory contains the licenses for some of the other libraries shipped with the distribution, that are not
covered by the LGPL-2.1 license.

It is important to note that not all the libraries shipped are needed in all cases and if you do not use certain
libraries you may not come under some of the licenses in this directory.

Infinispan requires 'infinispan-core.jar' as well as all libraries in the 'lib' directory to be on your classpath, or
packaged with your deployment.

This distribution also ships with a number of optional modules, in the 'modules' directory.  If you wish to use one or
more of these modules, you will also need the module's jar file and all of its dependencies ('modules/MODULE_NAME/lib')
to be on your classpath, in addition to the jars mentioned earlier.
